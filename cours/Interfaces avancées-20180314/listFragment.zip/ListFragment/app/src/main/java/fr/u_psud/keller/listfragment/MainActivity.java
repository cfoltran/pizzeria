package fr.u_psud.keller.listfragment;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

import fr.u_psud.keller.listfragment.items.Item;

public class MainActivity extends AppCompatActivity implements ItemFragment.OnListFragmentInteractionListener {

    Button zoneCouleur;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // On récupère les objets de l'interface
        zoneCouleur = (Button) findViewById(R.id.zoneCouleur);
    }

    // Contrôleur de la liste : modifie la couleur de la zone de couleur
    @Override
    public void onListFragmentInteraction(Item item) {
        Integer s = item.id;
        if (s.equals(1)) {
            zoneCouleur.setBackgroundColor(Color.rgb(255, 0, 0));
        } else if (s.equals(2)) {
            zoneCouleur.setBackgroundColor(Color.rgb(0, 255, 0));
        } else if (s.equals(3)) {
            zoneCouleur.setBackgroundColor(Color.rgb(0, 0, 255));
        } else {
            zoneCouleur.setBackgroundColor(Color.rgb(0, 0, 0));
        }
    }
}
