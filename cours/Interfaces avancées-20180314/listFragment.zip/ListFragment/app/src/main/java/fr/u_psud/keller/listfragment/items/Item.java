package fr.u_psud.keller.listfragment.items;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Item {

    // Un item : un identifiant et une chaîne de caractère représentant la couleur
    public final int id;
    public final String content;

    public Item(int id, String content) {
        this.id = id;
        this.content = content;
    }

    @Override
    public String toString() {
            return content;
        }

}
