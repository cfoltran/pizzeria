package fr.u_psud.keller.listfragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import fr.u_psud.keller.listfragment.items.Item;


public class ItemFragment extends Fragment {

    // Écouteur
    private OnListFragmentInteractionListener mListener;

    // Initialisation de l'interface
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Lecture du fichier XML
        View view = inflater.inflate(R.layout.fragment_item_list, container, false);

        // Écouteur sur les éléments de la liste
        if (view instanceof RecyclerView) {
            Context context = view.getContext();
            RecyclerView recyclerView = (RecyclerView) view;
            recyclerView.setLayoutManager(new LinearLayoutManager(context));
            recyclerView.setAdapter(new MyItemRecyclerViewAdapter(mListener));
        }
        return view;
    }

    // Création de l'écouteur lorsque le fragment est attaché
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnListFragmentInteractionListener) {
            mListener = (OnListFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnListFragmentInteractionListener");
        }
    }

    // Suppression de l'écouteur lorsque le fragment est détaché
    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    // Type de l'écouteur
    public interface OnListFragmentInteractionListener {
        void onListFragmentInteraction(Item item);
    }
}
