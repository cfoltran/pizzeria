package fr.u_psud.keller.dialogfragment;


import android.app.DialogFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class TestDialogFragment extends DialogFragment {

    int num;

    // Création d'une instance (le constructeur d'un fragment ne peut pas prendre d'arguments)
    static TestDialogFragment newInstance(int num) {
        TestDialogFragment f = new TestDialogFragment();
        f.num = num;
        return f;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

        // Titre et style de la boîte de dialogue
        getDialog().setTitle("Boîte de dialogue");
        setStyle(DialogFragment.STYLE_NORMAL, 0);

        // Affichage de la vue
        View v = inflater.inflate(R.layout.fragment_test_dialog, container, false);

        // Affichage du numéro dans la zone de texte
        TextView text = (TextView) v.findViewById(R.id.text);
        text.setText("Numéro " + num);

        // On renvoie la vue ainsi créée
        return v;
    }

}
