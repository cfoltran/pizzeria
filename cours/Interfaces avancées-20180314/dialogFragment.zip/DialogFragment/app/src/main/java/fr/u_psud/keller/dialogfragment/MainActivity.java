package fr.u_psud.keller.dialogfragment;

import android.app.DialogFragment;
import android.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    int compteur = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Le bouton permet de lancer la prochaine boîte de dialogue
        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog();
            }
        });
    }

    void showDialog() {
        // On incrémente la compteur
        compteur++;

        // Création et lancement de la boîte de dialogue
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        DialogFragment newFragment = TestDialogFragment.newInstance(compteur);
        newFragment.show(ft, "dialog");
    }
}
