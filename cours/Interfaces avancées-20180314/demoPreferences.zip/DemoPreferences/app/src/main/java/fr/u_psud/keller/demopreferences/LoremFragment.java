package fr.u_psud.keller.demopreferences;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Fragment;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class LoremFragment extends Fragment {

    TextView core;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Affichage de l'interface
        View res = inflater.inflate(R.layout.fragment_lorem, container, false);

        // Récupération des objets de l'interface
        core = (TextView) res.findViewById(R.id.core);

        return res;
    }

    // Application des préférences lorsque le fragment devient visible
    @Override
    public void onResume() {
        super.onResume();
        applyPref();
    }

    // Méthode pour appliquer les préférences :
    protected void applyPref() {
        // - récupérer les valeurs choisies par l'utilisateur
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(getActivity());
        boolean largeText = sharedPref.getBoolean(String.valueOf(getResources().getText(R.string.LARGE_TEXT)), false);

        // - les appliquer
        core.setTextSize(largeText ? 40 : 20);
    }
}
