package fr.u_psud.keller.demopreferences;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView title;

    LoremFragment loremFrag = new LoremFragment();
    PreferenceFragment prefFrag = new PrefFragment();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Récupération des objets de l'interface
        title = (TextView) findViewById(R.id.title);

        // Attachement du fragment "lorem ipsum" si premier lancement de l'activité
        if (!loremFrag.isAdded()) {
            getFragmentManager().beginTransaction().add(R.id.frag, loremFrag).commit();
        }
    }

    // Application des préférences lorsque l'activité devient visible
    @Override
    protected void onResume() {
        super.onResume();
        applyPref();
    }

    // Méthode pour appliquer les préférences :
    protected void applyPref() {
        // - récupérer les valeurs choisies par l'utilisateur
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        boolean redTitle = sharedPref.getBoolean(String.valueOf(getResources().getText(R.string.RED_TITLE)), true);
        String titleValue = sharedPref.getString(String.valueOf(getResources().getText(R.string.TITLE_VALUE)), String.valueOf(getResources().getText(R.string.lorem_ipsum)));
        boolean largeText = sharedPref.getBoolean(String.valueOf(getResources().getText(R.string.LARGE_TEXT)), false);

        // - les appliquer
        title.setTextColor(redTitle ? Color.RED : Color.BLACK);
        title.setText(titleValue);
        title.setTextSize(largeText ? 60 : 30);
    }

    // Méthode pour réinitialiser les préférences :
    private void initPref() {
        // - remettre les préférences aux valeurs par défaut
        PreferenceManager.getDefaultSharedPreferences(this).edit().clear().commit();
        PreferenceManager.setDefaultValues(this, R.xml.preferences, true);

        // - et ne pas oublier de les appliquer !
        applyPref(); loremFrag.applyPref();
    }

    // Création du menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    // Écouteur sur le menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // L'item sur lequel l'utilisateur a cliqué
        int id = item.getItemId();

        // Action choisie selon l'item
        if (id == R.id.action_settings) {
            // Attachement du fragment de préférences
            getFragmentManager().beginTransaction().addToBackStack("pref").replace(R.id.frag, prefFrag).commit();
            return true;
        }

        if (id == R.id.init_settings) {
            initPref();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
